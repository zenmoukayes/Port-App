# سجل الميناء — تطبيق أندرويد

تطبيق تسجيل شاحنات وأوزان تفريغ الباخرة. كل الواجهة داخل ملف واحد: `www/index.html`.

## كيف أحصل على ملف APK؟

### الطريقة ١ — GitHub Actions (بدون تثبيت أي برنامج)
1. أنشئ مستودعاً جديداً على GitHub وارفع محتويات هذا المجلد كما هي.
2. افتح تبويب **Actions** ← شغّل **بناء ملف APK** (أو انتظر، فهو يعمل تلقائياً عند الرفع).
3. بعد نحو ٥ دقائق نزّل الملف من قسم **Artifacts** باسم `sejil-almina-apk`.
4. انقل `app-debug.apk` إلى الجوال وثبّته بعد السماح بـ«تثبيت من مصادر غير معروفة».

### الطريقة ٢ — Android Studio على جهازك
```bash
npm install
npx cap sync android
npx cap open android      # ثم Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)
```

### الطريقة ٣ — سطر الأوامر (يحتاج Java 21 و Android SDK)
```bash
npm install
npx cap sync android
cd android && ./gradlew assembleDebug
# الناتج: android/app/build/outputs/apk/debug/app-debug.apk
```

## كيف أعدّل التطبيق بعد البناء؟
عدّل `www/index.html` فقط، ثم أعد الخطوات أعلاه. أي تعديل في الشكل أو الحقول
أو ملف الإكسل يتم في هذا الملف الواحد.

- تغيير المستخدمين: ابحث في الملف عن `var USERS` وعدّل الأسماء وكلمات المرور.
- تغيير اسم التطبيق: `android/app/src/main/res/values/strings.xml`
- تغيير معرّف الحزمة: `capacitor.config.json` (الحقل `appId`) ثم أعد `npx cap sync`.
- أيقونة التطبيق: استبدل الصور في `android/app/src/main/res/mipmap-*`.

## ملاحظات
- الاتجاه مقفول على الوضع العمودي، والتطبيق يعمل بلا إنترنت.
- البيانات محفوظة داخل الجهاز، ولا تُفقد عند إغلاق التطبيق أو تحديثه من داخل التطبيق.
- تحديث التطبيق بملف APK جديد يحافظ على البيانات ما دام معرّف الحزمة والتوقيع لم يتغيرا.
- ملف APK الناتج بصيغة debug، مناسب للاستخدام الداخلي. لنشره على Google Play يلزم بناء
  نسخة release موقّعة بمفتاح خاص.
