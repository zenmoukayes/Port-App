package com.port.sejil;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
